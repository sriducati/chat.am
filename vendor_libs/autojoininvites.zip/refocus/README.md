# Automatic entry box refocus

This plugin puts the focus on the entry box if the user clicks somewhere in the message list.

## Usage

```HTML
<script type="text/javascript" src="candyshop/refocus/candy.js"></script>
```

```JavaScript
CandyShop.Refocus.init();
```